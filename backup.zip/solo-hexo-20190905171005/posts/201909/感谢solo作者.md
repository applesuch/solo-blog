title: 感谢solo作者
date: '2019-09-04 17:29:52'
updated: '2019-09-04 17:29:52'
tags: [待分类]
permalink: /articles/2019/09/04/1567589392206.html
---
感谢solo作者，让我们有这么一个好的博客系统可用
